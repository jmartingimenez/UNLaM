<!DOCTYPE HTML>
<html>
<head>
	<title>superpagina</title>
	<style>
		table {
			font-family: arial, sans-serif;
			border-collapse: collapse;
			width: 100%;
		}

		td, th {
			border: 1px solid #dddddd;
			text-align: left;
			padding: 8px;
		}

		tr:nth-child(even) {
			background-color: #dddddd;
		}
	</style>
</head>
<body>
	<h1 style="text-align: center;">Listado de autos cargados</h1>
	<table>
		<tr>
			<th>Patente</th>
			<th>Marca</th>
			<th>Modelo</th>
			<th>Motor</th>
			<th>Costo</th>
		</tr>
		<?php
		$conexion = mysqli_connect("localhost", "root", "", "lunes19")
			or die("Error al conectarse al servidor");
			
		$consulta = "SELECT patente, marca, modelo, motor, costo FROM autosregistrados";
		$resultado = mysqli_query($conexion, $consulta);
		
		$nfilas = mysqli_num_rows($resultado);
		while($fila = mysqli_fetch_assoc($resultado)){
			echo "<tr><td>".$fila["patente"]."</td>";
			echo "<td>".$fila["marca"]."</td>";
			echo "<td>".$fila["modelo"]."</td>";
			echo "<td>".$fila["motor"]."</td>";
			echo "<td>".$fila["costo"]."</td></tr>";
		}
		mysqli_close($conexion);
		?>
	</table>
</body>
</html>