<!DOCTYPE HTML>
<html>
<head>
	<title>superpagina</title>
	<style>
		table {
			font-family: arial, sans-serif;
			border-collapse: collapse;
			width: 100%;
		}

		td, th {
			border: 1px solid #dddddd;
			text-align: left;
			padding: 8px;
		}

		tr:nth-child(even) {
			background-color: #dddddd;
		}
	</style>
</head>
<body>
	<?php
	include 'Consecionario.php';
	$cons = new Consecionario();
	?>
	<h1 style="text-align: center;">Listado de autos cargados</h1>
	<table>
		<tr>
			<th>Patente</th>
			<th>Marca</th>
			<th>Modelo</th>
			<th>Motor</th>
			<th>Costo</th>
		</tr>
		<?php
		$cons->mostrarAutos();
		?>
	</table>
</body>
</html>