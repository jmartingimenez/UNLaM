<?php
include 'Auto.php';

if(isset($_POST['enviar'])){
	$patente = $_POST['patente'];
	$marca = $_POST['marca'];
	$modelo = $_POST['modelo'];
	$motor = $_POST['motor'];
	$costo = $_POST['costo'];
	
	$autito = new Auto($patente, $marca, $modelo, $motor, $costo);
	$autito->guardar();
	header("Location:/lunes19/listado.php");
}
else{
	header("Location:/lunes19/index.html");
}
?>