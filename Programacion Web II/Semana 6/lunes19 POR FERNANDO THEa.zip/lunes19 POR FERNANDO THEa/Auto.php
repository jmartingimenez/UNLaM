<?php
class Auto{
	private $patente;
	private $marca;
	private $modelo;
	private $motor;
	private $costo;
	
	function __construct($pat, $mar, $mod, $mot, $cos){
		$this->patente = $pat;
		$this->marca = $mar;
		$this->modelo = $mod;
		$this->motor = $mot;
		$this->costo = $cos;
	}
	
	public function guardar(){
		$conexion = mysqli_connect("localhost", "root", "", "lunes19")
			or die("Error al conectarse al servidor");
			
		$insertar = mysqli_query($conexion, "INSERT INTO autosregistrados (id, patente, marca, modelo, motor, costo)
			VALUES ('NULL', '$this->patente', '$this->marca', '$this->modelo', '$this->motor', '$this->costo')")
			or die("Fallo la consulta");
			
	}
	
	public function getPatente(){
		return $this->patente;
	}
	
	public function getMarca(){
		return $this->marca;
	}
	
	public function getModelo(){
		return $this->modelo;
	}
	
	public function getMotor(){
		return $this->motor;
	}
	
	public function getCosto(){
		return $this->costo;
	}
}
?>