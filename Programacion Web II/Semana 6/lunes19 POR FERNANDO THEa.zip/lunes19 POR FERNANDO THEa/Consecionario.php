<?php
include 'Auto.php';

class Consecionario{
	private $autos;
	
	function __construct(){
		$this->autos = array();
		$this->cargarAutos();
	}
	
	public function cargarAutos(){
		$conexion = mysqli_connect("localhost", "root", "", "lunes19")
			or die("Error al conectarse al servidor");
			
		$consulta = "SELECT patente, marca, modelo, motor, costo FROM autosregistrados";
		$resultado = mysqli_query($conexion, $consulta);
		
		$nfilas = mysqli_num_rows($resultado);
		while($fila = mysqli_fetch_assoc($resultado)){
			$autito = new Auto($fila["patente"], $fila["marca"], $fila["modelo"], $fila["motor"], $fila["costo"]);
			$this->autos[] = $autito;
		}
		mysqli_close($conexion);
	}
	
	public function mostrarAutos(){
		foreach($this->autos as $auto){
			echo "<tr><td>".$auto->getPatente()."</td>";
			echo "<td>".$auto->getMarca()."</td>";
			echo "<td>".$auto->getModelo()."</td>";
			echo "<td>".$auto->getMotor()."</td>";
			echo "<td>".$auto->getCosto()."</td></tr>";
		}
	}
}

?>
