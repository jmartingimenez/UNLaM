package ar.edu.unlam.diit.scaw.daos.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import ar.edu.unlam.diit.scaw.daos.UsuarioDao;
import ar.edu.unlam.diit.scaw.entities.Usuario;

public class UsuarioDaoImpl implements UsuarioDao {

	@Autowired
	NamedParameterJdbcTemplate jdbcTemplate;

	public UsuarioDaoImpl() {
		super();
	}

	@Override
	public void save(Usuario usuario) {

		String sql = "INSERT INTO USUARIO (MINOMBRE, MIAPELLIDO, MIEMAIL) VALUES (:miNombre, :miApellido, :miEmail)";

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("miNombre", usuario.getMiNombre());
		params.put("miApellido", usuario.getMiApellido());
		params.put("miEmail", usuario.getMiEmail());
		jdbcTemplate.update(sql, params);

	}

	@Override
	public List<Usuario> getListado() {
		Map<String, Object> params = new HashMap<String, Object>();

		String sql = "SELECT * FROM USUARIO";

		List<Usuario> result = jdbcTemplate.query(sql, params, new UsuarioMapper());

		return result;
	}

	public NamedParameterJdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(NamedParameterJdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	private static final class UsuarioMapper implements RowMapper<Usuario> {

		public Usuario mapRow(ResultSet rs, int rowNum) throws SQLException {
			Usuario usuario = new Usuario();
			usuario.setId(rs.getInt("id"));
			usuario.setMiNombre(rs.getString("miNombre"));
			usuario.setMiApellido(rs.getString("miApellido"));
			usuario.setMiEmail(rs.getString("miEmail"));
			return usuario;
		}
	}

}
