package ar.edu.unlam.diit.scaw.beans;

import java.io.Serializable;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.faces.bean.ManagedBean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import ar.edu.unlam.diit.scaw.entities.Usuario;
import ar.edu.unlam.diit.scaw.services.UsuarioService;

@ManagedBean(name = "usuarioBean", eager = true)
@RequestScoped
public class UsuarioBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private String miNombre = null;
	private String miApellido = null;
	private String miEmail = null;
	
	//Spring Inject
	ApplicationContext context = new ClassPathXmlApplicationContext(new String[] {"beans.xml"});
	UsuarioService service = (UsuarioService) context.getBean("usuarioService");
	
	
	public UsuarioBean() {
		super();
	}
	
	public String save() {
		
		Usuario usuario = buildUsuario();
		
		service.save(usuario);
		
		return "pruebaBienvenida";
	}
	
	
	public List<Usuario> getListado() {
		List<Usuario> list = service.getListado();
		return list;
	}
	
	private Usuario buildUsuario() {
		Usuario usuario = new Usuario();
		usuario.setMiNombre(this.miNombre);
		usuario.setMiApellido(this.miApellido);
		usuario.setMiEmail(this.miEmail);
		
		return usuario;
	}

	public UsuarioBean(String miNombre, String miApellido, String miEmail) {
		super();
		this.miNombre = miNombre;
		this.miApellido = miApellido;
		this.miEmail = miEmail;
	}

	public String getMiNombre() {
		return miNombre;
	}

	public void setMiNombre(String miNombre) {
		this.miNombre = miNombre;
	}

	public String getMiApellido() {
		return miApellido;
	}

	public void setMiApellido(String miApellido) {
		this.miApellido = miApellido;
	}

	public String getMiEmail() {
		return miEmail;
	}

	public void setMiEmail(String miEmail) {
		this.miEmail = miEmail;
	}

}
