package ar.edu.unlam.diit.scaw.daos.impl;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLXML;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.hsqldb.jdbcDriver;
import org.hsqldb.jdbc.JDBCConnection;
import java.beans.Statement;
import org.hsqldb.persist.HsqlProperties;
import org.hsqldb.server.Server;
import org.hsqldb.server.ServerAcl.AclFormatException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import ar.edu.unlam.diit.scaw.daos.TareaDao;
import ar.edu.unlam.diit.scaw.entities.Tarea;
import org.hsqldb.Database;

public class TareaDaoImpl implements TareaDao {

	@Autowired
	NamedParameterJdbcTemplate jdbcTemplate;

	public TareaDaoImpl() {
		super();
	}

	Connection connection = null;
	java.sql.Statement statement = null;
	ResultSet resultSet = null;
	
	public boolean Conexion(){
		
		HsqlProperties hsqlProperties = new HsqlProperties();
		hsqlProperties.setProperty("server.database.0",
		  //"file:~/.hsqldb-2.3.4/DatoJava/HSQLDB/scawDB");
		  //"file:/home/dagger/Downloads/Grupo-1-I2/scawDB");
			"file:/Users/Victor/workspace/scaw/BaseDeDatos/scawDB");
		hsqlProperties.setProperty("server.dbname.0", "mdb");
		 
		 Server server = new Server();
		 try {
			server.setProperties(hsqlProperties);
		} catch (IOException e) {
			
			e.printStackTrace();
		} catch (AclFormatException e) {
			
			e.printStackTrace();
		}
		 server.setTrace(false); 
		 server.start();

		 try {
		     Class.forName("org.hsqldb.jdbc.JDBCDriver" );
		 } catch (Exception e) {
		     System.err.println("ERROR: failed to load HSQLDB JDBC driver.");
		     e.printStackTrace();
		     
		 }
		 
	     try {
			connection = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/mdb", "SA", "");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 try {
			statement =  connection.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		 
		 //agregar tareas
		 

		
			return true;
			
		}
	
	
	
	@Override
	public void guardarTarea(Tarea tarea, Integer usuarioId) {
		this.Conexion();
		String sql = "INSERT INTO Tareas (Titulo, Descripcion, EstadoId, Privacidad, TipoTarea, UsuarioAlta, UsuarioAsignado, FechaAlta) VALUES (:titulo, :descripcion, :estadoId, :privacidad, :tipoTarea, :usuarioAlta, :usuarioAsignado, :fechaAlta)";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("titulo", tarea.getTitulo());
		params.put("descripcion", tarea.getDescripcion());
		params.put("estadoId", tarea.getEstadoId());
		params.put("privacidad", tarea.getPrivacidad());
		params.put("tipoTarea", tarea.getTipoTarea());
		params.put("usuarioAlta", usuarioId);
		params.put("usuarioAsignado", tarea.getUsuarioAsignado());
		params.put("fechaAlta", tarea.getFechaAlta());
		jdbcTemplate.update(sql, params);

	}

	@Override
	public List<Tarea> listarTareasCreadas(Integer usuarioId) {
		this.Conexion();
		String sql = "SELECT * FROM Tareas WHERE usuarioAlta = :usuarioId";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("usuarioId", usuarioId);
		List<Tarea> result = jdbcTemplate.query(sql, params, new TareaMapper());
		return result;
	}
	
	@Override
	public List<Tarea> listarTareasAsignadas(Integer usuarioId) {
		this.Conexion();
		String sql = "SELECT * FROM Tareas WHERE usuarioAsignado = "+ usuarioId +"";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("usuarioId", usuarioId);
		List<Tarea> result = jdbcTemplate.query(sql, params, new TareaMapper());
		return result;
	}

	@Override
	public void eliminarTarea(Integer tareaId) {
		this.Conexion();
		String sql = "DELETE FROM Tareas WHERE tareaId LIKE :tareaId";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("tareaId", tareaId);
		jdbcTemplate.update(sql, params);		
	}
	
	@Override
	public void actualizarTarea(String tareaId, String titulo, String descripcion, Integer privacidad, Integer tipoTarea, Integer estadoId, Integer usuarioAsignado) {
		this.Conexion();
		String sql = "UPDATE Tareas SET titulo = " + titulo + ", descripcion = " + descripcion + ", privacidad = " + privacidad + ", tipoTarea = " + tipoTarea + ", estadoId = " + estadoId + ",usuarioAsignado = " + usuarioAsignado + " WHERE tareaId = " + tareaId + "";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("tareaId", Integer.parseInt(tareaId));
		params.put("titulo", titulo);
		params.put("descripcion", descripcion);
		params.put("privacidad", privacidad);
		params.put("tipoTarea", tipoTarea);
		params.put("estadoId", estadoId);		
		params.put("usuarioAsignado", usuarioAsignado);
		jdbcTemplate.update(sql, params);
	}
	
	@Override
	public List<Tarea> listarTareasAnonimo() {
		this.Conexion();
		String sql = "SELECT * FROM Tareas ";
		Map<String, Object> params = new HashMap<String, Object>();
		List<Tarea> resultAno = jdbcTemplate.query(sql, params, new TareaMapper());
		return resultAno;
	}
	
	public NamedParameterJdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(NamedParameterJdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	private static final class TareaMapper implements RowMapper<Tarea> {

		public Tarea mapRow(ResultSet rs, int rowNum) throws SQLException {
			Tarea tarea = new Tarea();
			tarea.setTareaId(rs.getInt("tareaId"));
			tarea.setTitulo(rs.getString("titulo"));
			tarea.setDescripcion(rs.getString("descripcion"));
			tarea.setEstadoId(rs.getInt("estadoId"));
			tarea.setPrivacidad(rs.getInt("privacidad"));
			tarea.setTipoTarea(rs.getInt("tipoTarea"));
			tarea.setUsuarioAlta(rs.getInt("usuarioAlta"));
			tarea.setUsuarioAsignado(rs.getInt("usuarioAsignado"));
			tarea.setFechaAlta(rs.getDate("fechaAlta"));
			return tarea;
		}
	}
}