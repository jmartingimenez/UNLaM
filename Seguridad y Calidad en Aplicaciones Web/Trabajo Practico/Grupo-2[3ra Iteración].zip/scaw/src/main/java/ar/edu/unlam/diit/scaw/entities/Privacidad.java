package ar.edu.unlam.diit.scaw.entities;

public class Privacidad {

	private Integer privacidadId;
	private String descripcion;
	
	public Privacidad() {
	}
	
	public Integer getPrivacidadId() {
		return privacidadId;
	}
	
	public void setPrivacidadId(Integer privacidadId) {
		this.privacidadId = privacidadId;
	}
	
	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
}
