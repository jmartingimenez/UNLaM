package ar.edu.unlam.diit.scaw.entities;

public class Rol {

	private Integer rolId;
	private String descripcion;
	
	public Rol() {
	}
	
	public Integer getRolId() {
		return rolId;
	}
	
	public void setRolId(Integer rolId) {
		this.rolId = rolId;
	}
	
	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
}