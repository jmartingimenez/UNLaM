package ar.edu.unlam.diit.scaw.entities;

public class Estado {

	private Integer estadoId;
	private String descripcion;
	
	public Estado() {
	}
	
	public Integer getEstadoId() {
		return estadoId;
	}
	
	public void setEstadoId(Integer estadoId) {
		this.estadoId = estadoId;
	}
	
	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
}
