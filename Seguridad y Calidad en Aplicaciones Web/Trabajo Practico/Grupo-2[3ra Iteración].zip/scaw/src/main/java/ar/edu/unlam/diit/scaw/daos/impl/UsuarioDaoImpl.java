package ar.edu.unlam.diit.scaw.daos.impl;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hsqldb.persist.HsqlProperties;
import org.hsqldb.server.Server;
import org.hsqldb.server.ServerAcl.AclFormatException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;

import ar.edu.unlam.diit.scaw.daos.UsuarioDao;
import ar.edu.unlam.diit.scaw.entities.Usuario;;

public class UsuarioDaoImpl implements UsuarioDao {

	Connection connection = null;
	java.sql.Statement statement = null;
	ResultSet resultSet = null;
	  
public boolean Conexion(){
	
	HsqlProperties hsqlProperties = new HsqlProperties();
	hsqlProperties.setProperty("server.database.0",
	  //"file:~/.hsqldb-2.3.4/hsqldb-2.3.4/DatoJava/HSQLDB/scawDB");
	  //"file:/home/dagger/Downloads/Grupo-1-I2/scawDB");
		"file:/Users/Victor/workspace/scaw/BaseDeDatos/scawDB");
	hsqlProperties.setProperty("server.dbname.0", "mdb");
	 

	
	 Server server = new Server();
	 try {
		server.setProperties(hsqlProperties);
	} catch (IOException e) {
		
		e.printStackTrace();
	} catch (AclFormatException e) {
		
		e.printStackTrace();
	}
	 server.setTrace(false); 
	 server.start();

	 try {
	     Class.forName("org.hsqldb.jdbc.JDBCDriver" );
	 } catch (Exception e) {
	     System.err.println("ERROR: failed to load HSQLDB JDBC driver.");
	     e.printStackTrace();
	     
	 }
	 
     try {
		connection = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/mdb", "SA", "");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 try {
		statement =  connection.createStatement();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	 return true;
		
	}

	
	
	@Autowired
	NamedParameterJdbcTemplate jdbcTemplate;

	public UsuarioDaoImpl() {
		super();
	}

	@Override
	public void guardarUsuario(Usuario usuario) {

	
		
		this.Conexion();
		
		try {
			statement.executeUpdate("INSERT INTO Usuarios (Nombre, Apellido, Email, Password, RolId, Activo, FechaAlta) VALUES ('"+usuario.getNombre()+"', '"+usuario.getApellido()+"', '"+usuario.getEmail()+"', '"+usuario.getPassword()+"', 2, false, CURDATE());");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	
	
	
	@Override
	public List<Usuario> listarUsuarios() {
		this.Conexion();
		String sql = "SELECT * FROM Usuarios";
		Map<String, Object> params = new HashMap<String, Object>();
		List<Usuario> result = jdbcTemplate.query(sql, params, new UsuarioMapper());
		return result;
	}
		
	@Override
	public List<Usuario> listarUsuariosInactivos() {
		this.Conexion();
		String sql = "SELECT * FROM Usuarios WHERE Activo = false";
		Map<String, Object> params = new HashMap<String, Object>();
		List<Usuario> result = jdbcTemplate.query(sql, params, new UsuarioMapper());
		return result;
	}
		
	@Override
	public void eliminarUsuario(Integer usuarioId) {
		this.Conexion();
		String sql = "DELETE FROM USUARIOS WHERE usuarioId LIKE :usuarioId ;";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("usuarioId", usuarioId);
		jdbcTemplate.update(sql, params);
		

	
		
		
		
	}
		
	@Override
	public void activarUsuario(Integer usuarioId, Boolean activo) {	
		activo = true;
		this.Conexion();
		String sql = "UPDATE Usuarios SET Activo = :activo, FechaAlta = CURDATE() WHERE UsuarioId = :usuarioId";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("activo", activo);
		params.put("usuarioId", usuarioId);
		jdbcTemplate.update(sql, params);		
	}
	
	@Override
      public Usuario buscarUsuario(String email, String password) {
		
		try{
			this.Conexion();
		String sql = "SELECT * FROM Usuarios WHERE email = " + email + " AND Password = "+ password +"";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("email", email);
		params.put("password", password);
		List<Usuario> result = jdbcTemplate.query(sql, params, new UsuarioMapper());
		if(result.size() == 0)//no encontró usuario
			return null;
		else
			return result.get(0);
		}
		catch(Exception e) {
			return new Usuario();
		}
	}
	
	@Override
	public Usuario crearSesion(String email, String password){
	
		this.Conexion();
		String sql = "SELECT * FROM Usuarios WHERE Email = '" + email + "' AND Password = '" + password + "' AND activo = :activo";
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("usuario", email);
		params.put("password", password);
		params.put("activo", true);
		List<Usuario> result = jdbcTemplate.query(sql, params, new UsuarioMapper());
		if(result.size() == 0)//no encontró usuario
			return null;
		else
			return result.get(0);		
	}

	public NamedParameterJdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(NamedParameterJdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	private static final class UsuarioMapper implements RowMapper<Usuario> {

		public Usuario mapRow(ResultSet rs, int rowNum) throws SQLException {
			Usuario usuario = new Usuario();
			usuario.setUsuarioId(rs.getInt("usuarioId"));
			usuario.setNombre(rs.getString("nombre"));
			usuario.setApellido(rs.getString("apellido"));
			usuario.setEmail(rs.getString("email"));
			usuario.setPassword(rs.getString("password"));
			usuario.setRolId(rs.getInt("rolId"));
			usuario.setActivo(rs.getBoolean("activo"));
			usuario.setFechaAlta(rs.getDate("fechaAlta"));
			return usuario;
		}
	}
}