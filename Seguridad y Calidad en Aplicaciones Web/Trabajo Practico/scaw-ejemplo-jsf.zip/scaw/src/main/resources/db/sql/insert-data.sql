INSERT INTO person (FIRSTNAME, LASTNAME, EMAIL) VALUES ('Cintia', 'Gioia', 'cgioia@unlam.edu.ar'); 
INSERT INTO person (FIRSTNAME, LASTNAME, EMAIL) VALUES ('Walter', 'Ureta', 'wureta@unlam.edu.ar');
INSERT INTO person (FIRSTNAME, LASTNAME, EMAIL) VALUES ('Juan', 'Monteagudo', 'jmonteagudo@unlam.edu.ar');

--COMMIT;